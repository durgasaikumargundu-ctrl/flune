import { motion } from "framer-motion";
import AnimatedAvatar from "./AnimatedAvatar";
import { Badge } from "@/components/ui/badge";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

type MessageRole = "user" | "manager";
type EmotionState = "serious" | "excited" | "calm";

interface ChatMessageProps {
  role: MessageRole;
  content: string;
  emotion?: EmotionState;
  assistants?: string[];
  timestamp?: string;
}

export default function ChatMessage({
  role,
  content,
  emotion = "calm",
  assistants = [],
  timestamp,
}: ChatMessageProps) {
  const isUser = role === "user";

  return (
    <motion.div
      className={`flex gap-4 ${isUser ? "flex-row-reverse" : "flex-row"} mb-6`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      data-testid={`message-${role}`}
    >
      {!isUser && <AnimatedAvatar emotion={emotion} size="sm" />}
      
      <div className={`flex flex-col gap-2 max-w-2xl ${isUser ? "items-end" : "items-start"}`}>
        <div
          className={`px-6 py-4 rounded-3xl backdrop-blur-xl border ${
            isUser
              ? "bg-primary/10 border-primary/20"
              : "bg-card/50 border-card-border"
          }`}
          data-testid={`message-content-${role}`}
        >
          <div className="prose prose-sm dark:prose-invert max-w-none">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{content}</ReactMarkdown>
          </div>
        </div>
        
        {!isUser && assistants.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {assistants.map((assistant) => (
              <Badge
                key={assistant}
                variant="secondary"
                className="text-xs"
                data-testid={`badge-assistant-${assistant}`}
              >
                {assistant}
              </Badge>
            ))}
          </div>
        )}
        
        {timestamp && (
          <span className="text-xs text-muted-foreground" data-testid="message-timestamp">
            {timestamp}
          </span>
        )}
      </div>
    </motion.div>
  );
}
