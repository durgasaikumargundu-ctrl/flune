import { motion, AnimatePresence } from "framer-motion";
import AssistantCard from "./AssistantCard";

type AssistantType = "Thinker" | "Writer" | "Coder" | "Researcher" | "Designer";

interface AssistantState {
  type: AssistantType;
  status: "idle" | "working" | "done";
  progress: number;
  statusText: string;
}

interface AssistantWorkspaceProps {
  assistants: AssistantState[];
  isVisible: boolean;
}

export default function AssistantWorkspace({ assistants, isVisible }: AssistantWorkspaceProps) {
  if (!isVisible) return null;

  return (
    <motion.div
      className="mb-6 p-6 rounded-2xl backdrop-blur-xl bg-card/20 border border-card-border"
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.4 }}
      data-testid="assistant-workspace"
    >
      <div className="flex items-center gap-2 mb-4">
        <div className="w-2 h-2 rounded-full bg-neon-glow animate-pulse" />
        <span className="text-sm font-medium text-muted-foreground">
          AI Control Room — Assistants Working
        </span>
      </div>
      
      <div className="flex flex-wrap gap-4 justify-center">
        <AnimatePresence>
          {assistants.map((assistant) => (
            <AssistantCard
              key={assistant.type}
              type={assistant.type}
              status={assistant.status}
              progress={assistant.progress}
              statusText={assistant.statusText}
            />
          ))}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
