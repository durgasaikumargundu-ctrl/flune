import { useState } from "react";
import { Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import VoiceButton from "./VoiceButton";

interface ChatInputProps {
  onSend: (message: string) => void;
  disabled?: boolean;
}

export default function ChatInput({ onSend, disabled = false }: ChatInputProps) {
  const [message, setMessage] = useState("");

  const handleSend = () => {
    if (message.trim() && !disabled) {
      onSend(message);
      setMessage("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleVoiceTranscript = (text: string) => {
    setMessage(text);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 p-4 backdrop-blur-xl bg-background/80 border-t border-border">
      <div className="max-w-4xl mx-auto flex items-end gap-2">
        <VoiceButton onTranscript={handleVoiceTranscript} />
        
        <Textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ask your AI manager anything..."
          className="resize-none min-h-[60px] max-h-[120px]"
          disabled={disabled}
          data-testid="input-message"
        />
        
        <Button
          size="icon"
          onClick={handleSend}
          disabled={!message.trim() || disabled}
          className="shrink-0"
          data-testid="button-send"
        >
          <Send className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}
