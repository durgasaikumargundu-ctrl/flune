import { useCallback } from "react";
import Particles from "react-tsparticles";
import { loadSlim } from "tsparticles-slim";
import type { Engine } from "tsparticles-engine";

type EmotionState = "serious" | "excited" | "calm";

interface ParticleBackgroundProps {
  emotion?: EmotionState;
}

export default function ParticleBackground({ emotion = "calm" }: ParticleBackgroundProps) {
  const particlesInit = useCallback(async (engine: Engine) => {
    await loadSlim(engine);
  }, []);

  const getEmotionConfig = () => {
    switch (emotion) {
      case "serious":
        return { speed: 0.5, color: "#60a5fa", count: 30 };
      case "excited":
        return { speed: 2, color: "#fb923c", count: 60 };
      case "calm":
      default:
        return { speed: 1, color: "#a78bfa", count: 40 };
    }
  };

  const config = getEmotionConfig();

  return (
    <Particles
      id="tsparticles"
      init={particlesInit}
      options={{
        fullScreen: {
          enable: true,
          zIndex: 0,
        },
        background: {
          color: {
            value: "transparent",
          },
        },
        fpsLimit: 60,
        interactivity: {
          events: {
            onClick: {
              enable: true,
              mode: "push",
            },
            onHover: {
              enable: true,
              mode: "repulse",
            },
            resize: true,
          },
          modes: {
            push: {
              quantity: 2,
            },
            repulse: {
              distance: 100,
              duration: 0.4,
            },
          },
        },
        particles: {
          color: {
            value: config.color,
          },
          links: {
            color: config.color,
            distance: 150,
            enable: true,
            opacity: 0.2,
            width: 1,
          },
          move: {
            direction: "none",
            enable: true,
            outModes: {
              default: "bounce",
            },
            random: false,
            speed: config.speed,
            straight: false,
          },
          number: {
            density: {
              enable: true,
              area: 800,
            },
            value: config.count,
          },
          opacity: {
            value: 0.3,
          },
          shape: {
            type: "circle",
          },
          size: {
            value: { min: 1, max: 3 },
          },
        },
        detectRetina: true,
      }}
    />
  );
}
