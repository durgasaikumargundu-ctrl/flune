import TypingIndicator from "../TypingIndicator";

export default function TypingIndicatorExample() {
  return (
    <div className="flex items-center justify-center p-8">
      <div className="p-4 rounded-lg bg-card">
        <TypingIndicator />
      </div>
    </div>
  );
}
