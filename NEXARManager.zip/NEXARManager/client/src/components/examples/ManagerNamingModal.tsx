import ManagerNamingModal from "../ManagerNamingModal";

export default function ManagerNamingModalExample() {
  return (
    <ManagerNamingModal
      isOpen={true}
      onComplete={(name) => console.log("Manager named:", name)}
    />
  );
}
