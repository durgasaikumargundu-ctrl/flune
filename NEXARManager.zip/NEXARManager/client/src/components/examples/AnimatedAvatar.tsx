import AnimatedAvatar from "../AnimatedAvatar";

export default function AnimatedAvatarExample() {
  return (
    <div className="flex items-center justify-center gap-8 p-8">
      <AnimatedAvatar emotion="serious" size="sm" />
      <AnimatedAvatar emotion="calm" size="md" />
      <AnimatedAvatar emotion="excited" size="lg" />
    </div>
  );
}
