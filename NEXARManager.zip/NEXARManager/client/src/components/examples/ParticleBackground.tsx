import ParticleBackground from "../ParticleBackground";

export default function ParticleBackgroundExample() {
  return <ParticleBackground emotion="calm" />;
}
