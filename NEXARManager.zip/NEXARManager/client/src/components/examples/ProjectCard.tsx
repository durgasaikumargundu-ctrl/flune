import ProjectCard from "../ProjectCard";

export default function ProjectCardExample() {
  return (
    <div className="max-w-sm p-8">
      <ProjectCard
        title="Website Redesign"
        progress={75}
        tasks={[
          { text: "Design mockups", completed: true },
          { text: "Develop components", completed: true },
          { text: "Deploy to production", completed: false },
        ]}
        aiActivity={[
          { assistant: "Designer", action: "Created color palette" },
          { assistant: "Coder", action: "Built React components" },
        ]}
        createdAt="Nov 1, 2025"
      />
    </div>
  );
}
