import AssistantWorkspace from "../AssistantWorkspace";

export default function AssistantWorkspaceExample() {
  const assistants = [
    { type: "Thinker" as const, status: "working" as const, progress: 75, statusText: "Planning structure..." },
    { type: "Writer" as const, status: "working" as const, progress: 45, statusText: "Drafting content..." },
    { type: "Researcher" as const, status: "done" as const, progress: 100, statusText: "Complete" },
  ];

  return (
    <div className="max-w-4xl mx-auto p-8">
      <AssistantWorkspace assistants={assistants} isVisible={true} />
    </div>
  );
}
