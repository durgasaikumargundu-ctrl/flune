import VoiceButton from "../VoiceButton";

export default function VoiceButtonExample() {
  return (
    <div className="flex items-center justify-center p-8">
      <VoiceButton onTranscript={(text) => console.log("Transcribed:", text)} />
    </div>
  );
}
