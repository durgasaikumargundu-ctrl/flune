import ChatMessage from "../ChatMessage";

export default function ChatMessageExample() {
  return (
    <div className="max-w-4xl mx-auto p-8 space-y-4">
      <ChatMessage
        role="user"
        content="Create a business plan for a startup"
        timestamp="2:30 PM"
      />
      <ChatMessage
        role="manager"
        content="I've analyzed your request and delegated tasks to my specialized assistants. Here's your comprehensive business plan with market analysis, financial projections, and growth strategy."
        emotion="serious"
        assistants={["Thinker", "Writer", "Researcher"]}
        timestamp="2:31 PM"
      />
    </div>
  );
}
