import ChatInput from "../ChatInput";

export default function ChatInputExample() {
  return (
    <div className="h-screen flex items-end">
      <div className="w-full">
        <ChatInput onSend={(message) => console.log("Sent:", message)} />
      </div>
    </div>
  );
}
