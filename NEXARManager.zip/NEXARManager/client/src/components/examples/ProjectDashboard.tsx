import ProjectDashboard from "../ProjectDashboard";

export default function ProjectDashboardExample() {
  return <ProjectDashboard />;
}
