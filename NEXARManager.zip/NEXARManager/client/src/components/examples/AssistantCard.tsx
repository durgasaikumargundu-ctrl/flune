import AssistantCard from "../AssistantCard";

export default function AssistantCardExample() {
  return (
    <div className="flex flex-wrap gap-4 p-8 justify-center">
      <AssistantCard type="Thinker" status="working" progress={60} statusText="Analyzing..." />
      <AssistantCard type="Writer" status="done" progress={100} statusText="Complete" />
      <AssistantCard type="Coder" status="idle" progress={0} statusText="Idle" />
      <AssistantCard type="Researcher" status="working" progress={30} statusText="Searching..." />
      <AssistantCard type="Designer" status="idle" progress={0} statusText="Ready" />
    </div>
  );
}
