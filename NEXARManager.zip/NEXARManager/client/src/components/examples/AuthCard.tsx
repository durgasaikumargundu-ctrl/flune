import AuthCard from "../AuthCard";

export default function AuthCardExample() {
  return (
    <div className="flex items-center justify-center min-h-screen p-8">
      <AuthCard
        onAuth={(email, password, isSignup) => console.log({ email, password, isSignup })}
        onGoogleAuth={() => console.log("Google auth clicked")}
      />
    </div>
  );
}
