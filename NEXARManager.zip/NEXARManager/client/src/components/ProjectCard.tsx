import { motion } from "framer-motion";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, TrendingUp } from "lucide-react";

interface ProjectCardProps {
  title: string;
  progress: number;
  tasks: { text: string; completed: boolean }[];
  aiActivity: { assistant: string; action: string }[];
  createdAt: string;
}

export default function ProjectCard({
  title,
  progress,
  tasks,
  aiActivity,
  createdAt,
}: ProjectCardProps) {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
      data-testid={`card-project-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <Card className="hover-elevate">
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-4">
          <h3 className="text-lg font-semibold truncate" data-testid="text-project-title">{title}</h3>
          <Badge variant="secondary" className="shrink-0" data-testid="badge-progress">
            {progress}%
          </Badge>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <Progress value={progress} className="h-2" data-testid="progress-bar" />
          
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-muted-foreground">Recent Tasks</h4>
            {tasks.slice(0, 3).map((task, idx) => (
              <div key={idx} className="flex items-center gap-2 text-sm" data-testid={`task-${idx}`}>
                <div
                  className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                    task.completed ? "bg-primary border-primary" : "border-muted-foreground"
                  }`}
                >
                  {task.completed && <div className="w-2 h-2 rounded-full bg-primary-foreground" />}
                </div>
                <span className={task.completed ? "line-through text-muted-foreground" : ""}>
                  {task.text}
                </span>
              </div>
            ))}
          </div>
          
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-muted-foreground">AI Activity</h4>
            {aiActivity.slice(0, 2).map((activity, idx) => (
              <div key={idx} className="flex items-center gap-2 text-xs" data-testid={`activity-${idx}`}>
                <Badge variant="outline" className="shrink-0">
                  {activity.assistant}
                </Badge>
                <span className="text-muted-foreground truncate">{activity.action}</span>
              </div>
            ))}
          </div>
        </CardContent>
        
        <CardFooter className="flex items-center justify-between gap-2 pt-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Calendar className="w-3 h-3" />
            <span data-testid="text-created-date">{createdAt}</span>
          </div>
          <Button variant="ghost" size="sm" data-testid="button-view-details">
            <TrendingUp className="w-4 h-4 mr-2" />
            View Details
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
