import ProjectCard from "./ProjectCard";

//TODO: remove mock functionality
const mockProjects = [
  {
    title: "Website Redesign",
    progress: 75,
    tasks: [
      { text: "Design mockups", completed: true },
      { text: "Develop components", completed: true },
      { text: "Deploy to production", completed: false },
    ],
    aiActivity: [
      { assistant: "Designer", action: "Created color palette" },
      { assistant: "Coder", action: "Built React components" },
    ],
    createdAt: "Nov 1, 2025",
  },
  {
    title: "Business Plan Draft",
    progress: 45,
    tasks: [
      { text: "Market research", completed: true },
      { text: "Financial projections", completed: false },
      { text: "Executive summary", completed: false },
    ],
    aiActivity: [
      { assistant: "Researcher", action: "Analyzed market trends" },
      { assistant: "Writer", action: "Drafted introduction" },
    ],
    createdAt: "Oct 28, 2025",
  },
  {
    title: "API Integration",
    progress: 90,
    tasks: [
      { text: "Setup endpoints", completed: true },
      { text: "Test API calls", completed: true },
      { text: "Write documentation", completed: false },
    ],
    aiActivity: [
      { assistant: "Coder", action: "Created API routes" },
      { assistant: "Thinker", action: "Planned architecture" },
    ],
    createdAt: "Oct 25, 2025",
  },
];

export default function ProjectDashboard() {
  return (
    <div className="p-8 pb-32" data-testid="project-dashboard">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Projects</h1>
          <p className="text-muted-foreground">
            Track your AI-managed projects and their progress
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockProjects.map((project) => (
            <ProjectCard key={project.title} {...project} />
          ))}
        </div>
      </div>
    </div>
  );
}
