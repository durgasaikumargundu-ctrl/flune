import { useState } from "react";
import { motion } from "framer-motion";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import AnimatedAvatar from "./AnimatedAvatar";

interface ManagerNamingModalProps {
  isOpen: boolean;
  onComplete: (name: string) => void;
}

export default function ManagerNamingModal({ isOpen, onComplete }: ManagerNamingModalProps) {
  const [managerName, setManagerName] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (managerName.trim()) {
      onComplete(managerName);
    }
  };

  return (
    <Dialog open={isOpen}>
      <DialogContent className="sm:max-w-md backdrop-blur-xl" data-testid="modal-manager-naming">
        <DialogHeader>
          <DialogTitle className="text-center text-2xl">Welcome to NEXAR</DialogTitle>
          <DialogDescription className="text-center">
            Let's personalize your AI manager
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex flex-col items-center gap-6 py-6">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
          >
            <AnimatedAvatar size="lg" />
          </motion.div>
          
          <form onSubmit={handleSubmit} className="w-full space-y-4">
            <div className="space-y-2">
              <label htmlFor="manager-name" className="text-sm font-medium text-center block">
                What would you like to name your manager?
              </label>
              <Input
                id="manager-name"
                value={managerName}
                onChange={(e) => setManagerName(e.target.value)}
                placeholder="e.g., Nexar, Nova, Atlas..."
                className="text-center text-lg"
                autoFocus
                data-testid="input-manager-name"
              />
            </div>
            
            <Button
              type="submit"
              className="w-full"
              disabled={!managerName.trim()}
              data-testid="button-continue"
            >
              Continue
            </Button>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
