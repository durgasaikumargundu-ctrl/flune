import { useState } from "react";
import { motion } from "framer-motion";
import { Mic, MicOff } from "lucide-react";
import { Button } from "@/components/ui/button";

interface VoiceButtonProps {
  onTranscript?: (text: string) => void;
}

export default function VoiceButton({ onTranscript }: VoiceButtonProps) {
  const [isRecording, setIsRecording] = useState(false);

  const handleToggleRecording = () => {
    //TODO: remove mock functionality - implement Web Speech API
    setIsRecording(!isRecording);
    console.log(isRecording ? "Stopped recording" : "Started recording");
    
    if (isRecording && onTranscript) {
      onTranscript("Sample voice transcription");
    }
  };

  return (
    <Button
      size="icon"
      variant="ghost"
      onClick={handleToggleRecording}
      className="relative"
      data-testid="button-voice-input"
    >
      {isRecording ? (
        <motion.div
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 1, repeat: Infinity }}
        >
          <MicOff className="w-5 h-5 text-destructive" />
        </motion.div>
      ) : (
        <Mic className="w-5 h-5" />
      )}
      
      {isRecording && (
        <motion.div
          className="absolute inset-0 rounded-full border-2 border-destructive"
          animate={{ scale: [1, 1.5], opacity: [1, 0] }}
          transition={{ duration: 1, repeat: Infinity }}
        />
      )}
    </Button>
  );
}
