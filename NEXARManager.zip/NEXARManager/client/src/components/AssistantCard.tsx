import { motion } from "framer-motion";
import { Brain, FileText, Code, Search, Palette } from "lucide-react";
import { Progress } from "@/components/ui/progress";

type AssistantType = "Thinker" | "Writer" | "Coder" | "Researcher" | "Designer";
type AssistantStatus = "idle" | "working" | "done";

interface AssistantCardProps {
  type: AssistantType;
  status: AssistantStatus;
  progress?: number;
  statusText?: string;
}

const assistantConfig = {
  Thinker: { icon: Brain, color: "text-neon-blue" },
  Writer: { icon: FileText, color: "text-neon-purple" },
  Coder: { icon: Code, color: "text-neon-glow" },
  Researcher: { icon: Search, color: "text-neon-pulse" },
  Designer: { icon: Palette, color: "text-emotion-excited" },
};

export default function AssistantCard({
  type,
  status,
  progress = 0,
  statusText = "Idle",
}: AssistantCardProps) {
  const config = assistantConfig[type];
  const Icon = config.icon;

  const getGlow = () => {
    if (status === "done") return "0 0 15px rgba(34, 197, 94, 0.5)";
    if (status === "working") return "0 0 15px rgba(167, 139, 250, 0.5)";
    return "none";
  };

  return (
    <motion.div
      className="flex flex-col items-center gap-2 p-4 rounded-xl backdrop-blur-xl bg-card/30 border border-card-border min-w-[120px]"
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{
        opacity: 1,
        scale: 1,
        boxShadow: getGlow(),
      }}
      exit={{ opacity: 0, scale: 0.8 }}
      transition={{ duration: 0.4 }}
      data-testid={`assistant-card-${type.toLowerCase()}`}
    >
      <motion.div
        animate={{
          rotate: status === "working" ? 360 : 0,
        }}
        transition={{
          duration: 2,
          repeat: status === "working" ? Infinity : 0,
          ease: "linear",
        }}
      >
        <Icon className={`w-8 h-8 ${config.color}`} data-testid={`icon-${type.toLowerCase()}`} />
      </motion.div>
      
      <span className="text-xs font-semibold uppercase tracking-wider" data-testid={`name-${type.toLowerCase()}`}>
        {type}
      </span>
      
      {status === "working" && (
        <div className="w-full" data-testid={`progress-${type.toLowerCase()}`}>
          <Progress value={progress} className="h-1" />
        </div>
      )}
      
      <span className="text-xs text-muted-foreground" data-testid={`status-${type.toLowerCase()}`}>
        {status === "done" ? "Done ✅" : statusText}
      </span>
    </motion.div>
  );
}
