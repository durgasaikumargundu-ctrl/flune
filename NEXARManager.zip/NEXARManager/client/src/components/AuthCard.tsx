import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SiGoogle } from "react-icons/si";

interface AuthCardProps {
  onAuth: (email: string, password: string, isSignup: boolean) => void;
  onGoogleAuth: () => void;
}

export default function AuthCard({ onAuth, onGoogleAuth }: AuthCardProps) {
  const [isSignup, setIsSignup] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAuth(email, password, isSignup);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
      data-testid="auth-card"
    >
      <Card className="w-full max-w-md backdrop-blur-xl bg-card/50 border-card-border">
        <CardHeader className="space-y-2 text-center">
          <h1 className="text-3xl font-bold gradient-text">NEXAR</h1>
          <p className="text-muted-foreground">Your AI Manager</p>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                data-testid="input-email"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                data-testid="input-password"
              />
            </div>
            
            <Button type="submit" className="w-full" data-testid="button-submit">
              {isSignup ? "Sign Up" : "Sign In"}
            </Button>
          </form>
          
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
            </div>
          </div>
          
          <Button
            variant="outline"
            className="w-full"
            onClick={onGoogleAuth}
            data-testid="button-google"
          >
            <SiGoogle className="w-4 h-4 mr-2" />
            Google
          </Button>
        </CardContent>
        
        <CardFooter className="flex justify-center">
          <Button
            variant="ghost"
            onClick={() => setIsSignup(!isSignup)}
            data-testid="button-toggle-mode"
          >
            {isSignup ? "Already have an account? Sign in" : "Don't have an account? Sign up"}
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
