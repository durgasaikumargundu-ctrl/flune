import { motion } from "framer-motion";
import managerAvatarImage from "@assets/generated_images/AI_Manager_Holographic_Avatar_013c5079.png";

type EmotionState = "serious" | "excited" | "calm";

interface AnimatedAvatarProps {
  emotion?: EmotionState;
  size?: "sm" | "md" | "lg";
}

export default function AnimatedAvatar({ emotion = "calm", size = "md" }: AnimatedAvatarProps) {
  const getEmotionGlow = () => {
    switch (emotion) {
      case "serious":
        return "0 0 20px rgba(96, 165, 250, 0.6), 0 0 40px rgba(96, 165, 250, 0.3)";
      case "excited":
        return "0 0 20px rgba(251, 146, 60, 0.6), 0 0 40px rgba(251, 146, 60, 0.3)";
      case "calm":
      default:
        return "0 0 20px rgba(167, 139, 250, 0.6), 0 0 40px rgba(167, 139, 250, 0.3)";
    }
  };

  const sizeClasses = {
    sm: "w-16 h-16",
    md: "w-24 h-24",
    lg: "w-32 h-32",
  };

  return (
    <motion.div
      className={`${sizeClasses[size]} rounded-full overflow-hidden relative`}
      animate={{
        y: [0, -10, 0],
        boxShadow: [getEmotionGlow(), getEmotionGlow(), getEmotionGlow()],
      }}
      transition={{
        duration: 3,
        repeat: Infinity,
        ease: "easeInOut",
      }}
      data-testid="animated-avatar"
    >
      <img
        src={managerAvatarImage}
        alt="AI Manager Avatar"
        className="w-full h-full object-cover"
      />
      <motion.div
        className="absolute inset-0 rounded-full"
        animate={{
          opacity: [0.3, 0.6, 0.3],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        style={{
          background: `radial-gradient(circle, ${emotion === "serious" ? "rgba(96, 165, 250, 0.2)" : emotion === "excited" ? "rgba(251, 146, 60, 0.2)" : "rgba(167, 139, 250, 0.2)"} 0%, transparent 70%)`,
        }}
      />
    </motion.div>
  );
}
