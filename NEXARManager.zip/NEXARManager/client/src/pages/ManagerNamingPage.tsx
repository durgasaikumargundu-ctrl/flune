import { useLocation } from "wouter";
import ParticleBackground from "@/components/ParticleBackground";
import ManagerNamingModal from "@/components/ManagerNamingModal";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function ManagerNamingPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleComplete = async (name: string) => {
    const userId = localStorage.getItem("nexar-user-id");
    if (!userId) {
      toast({
        title: "Error",
        description: "No user session found",
        variant: "destructive",
      });
      setLocation("/");
      return;
    }

    try {
      await apiRequest("PATCH", `/api/users/${userId}/manager-name`, { managerName: name });

      localStorage.setItem("nexar-manager-name", name);
      setLocation("/chat");
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to save manager name",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen relative">
      <ParticleBackground emotion="excited" />
      <ManagerNamingModal isOpen={true} onComplete={handleComplete} />
    </div>
  );
}
