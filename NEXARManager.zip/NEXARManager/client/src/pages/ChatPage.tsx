import { useState, useEffect, useRef } from "react";
import { useLocation, Link } from "wouter";
import ParticleBackground from "@/components/ParticleBackground";
import ChatMessage from "@/components/ChatMessage";
import ChatInput from "@/components/ChatInput";
import AssistantWorkspace from "@/components/AssistantWorkspace";
import TypingIndicator from "@/components/TypingIndicator";
import ThemeToggle from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { FolderKanban, LogOut } from "lucide-react";
import { io, Socket } from "socket.io-client";
import { useQuery } from "@tanstack/react-query";
import { logout } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";

type Message = {
  role: "user" | "manager";
  content: string;
  emotion?: "serious" | "excited" | "calm";
  assistants?: string[];
  timestamp: string;
};

type AssistantState = {
  type: "Thinker" | "Writer" | "Coder" | "Researcher" | "Designer";
  status: "idle" | "working" | "done";
  progress: number;
  statusText: string;
};

export default function ChatPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const userId = localStorage.getItem("nexar-user-id");
  const managerName = localStorage.getItem("nexar-manager-name") || "Nexar";
  const socketRef = useRef<Socket | null>(null);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [assistants, setAssistants] = useState<AssistantState[]>([]);
  const [currentEmotion, setCurrentEmotion] = useState<"serious" | "excited" | "calm">("calm");

  // Redirect if not authenticated
  useEffect(() => {
    if (!userId) {
      setLocation("/");
    }
  }, [userId, setLocation]);

  // Create or load conversation
  useEffect(() => {
    if (!userId) return;

    const initConversation = async () => {
      try {
        const { apiRequest } = await import("@/lib/queryClient");
        
        const conversationsResponse = await apiRequest("GET", `/api/conversations/${userId}`);
        const conversations = await conversationsResponse.json();
        
        if (conversations.length > 0) {
          const latest = conversations[0];
          setConversationId(latest.id);
          
          const messagesResponse = await apiRequest("GET", `/api/conversations/${latest.id}/messages`);
          const loadedMessages = await messagesResponse.json();
          
          setMessages(loadedMessages.map((m: any) => ({
            role: m.role,
            content: m.content,
            emotion: m.emotion,
            assistants: m.assistants,
            timestamp: new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          })));
        } else {
          const createResponse = await apiRequest("POST", "/api/conversations", {
            title: "New Conversation",
          });
          const newConversation = await createResponse.json();
          setConversationId(newConversation.id);
          
          setMessages([{
            role: "manager",
            content: `Hi! I'm **${managerName}**, your personal AI manager. I coordinate a team of specialized AI assistants to help you accomplish any task. Just tell me what you need!`,
            emotion: "excited",
            assistants: [],
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          }]);
        }
      } catch (error) {
        console.error("Failed to load conversation:", error);
        toast({
          title: "Error",
          description: "Failed to load conversation. Please try refreshing the page.",
          variant: "destructive",
        });
      }
    };

    initConversation();
  }, [userId, managerName, toast]);

  // Setup Socket.io connection
  useEffect(() => {
    const setupSocket = async () => {
      const user = (await import("@/lib/firebase")).auth.currentUser;
      if (!user) return;

      const token = await user.getIdToken();
      socketRef.current = io({
        auth: { token },
      });

      socketRef.current.on("emotion-detected", ({ emotion }) => {
        setCurrentEmotion(emotion);
      });

    socketRef.current.on("assistants-activated", ({ assistants: activatedAssistants }) => {
      const assistantStates: AssistantState[] = activatedAssistants.map((type: string) => ({
        type: type as any,
        status: "idle" as const,
        progress: 0,
        statusText: "Initializing...",
      }));
      setAssistants(assistantStates);
    });

    socketRef.current.on("assistant-progress", ({ assistant, status, progress }) => {
      setAssistants((prev) =>
        prev.map((a) =>
          a.type === assistant
            ? {
                ...a,
                status,
                progress,
                statusText: status === "working" ? "Processing..." : "Complete",
              }
            : a
        )
      );
    });

    socketRef.current.on("manager-response", ({ content, emotion, assistants: usedAssistants }) => {
      const managerMessage: Message = {
        role: "manager",
        content,
        emotion,
        assistants: usedAssistants,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      
      setMessages((prev) => [...prev, managerMessage]);
      setIsProcessing(false);
      setAssistants([]);
      setCurrentEmotion("calm");
    });

      socketRef.current.on("error", ({ message }) => {
        toast({
          title: "Error",
          description: message,
          variant: "destructive",
        });
        setIsProcessing(false);
        setAssistants([]);
        setCurrentEmotion("calm");
      });
    };

    setupSocket();

    return () => {
      socketRef.current?.disconnect();
    };
  }, [toast]);

  const handleSend = async (message: string) => {
    if (!conversationId || !socketRef.current) return;

    const userMessage: Message = {
      role: "user",
      content: message,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setIsProcessing(true);
    setCurrentEmotion("serious");

    socketRef.current.emit("chat-message", {
      userId,
      conversationId,
      userMessage: message,
      managerName,
    });
  };

  const handleLogout = async () => {
    try {
      await logout();
      localStorage.removeItem("nexar-manager-name");
      localStorage.removeItem("nexar-user-id");
      setLocation("/");
    } catch (error: any) {
      toast({
        title: "Logout Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen relative">
      <ParticleBackground emotion={currentEmotion} />
      
      <header className="fixed top-0 left-0 right-0 z-20 backdrop-blur-xl bg-background/80 border-b border-border">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold gradient-text">{managerName}</h1>
            <span className="text-xs text-muted-foreground">Your AI Manager</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" data-testid="button-projects">
                <FolderKanban className="w-4 h-4 mr-2" />
                Projects
              </Button>
            </Link>
            <ThemeToggle />
            <Button variant="ghost" size="icon" onClick={handleLogout} data-testid="button-logout">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>
      
      <main className="relative z-10 pt-20 pb-40 px-4">
        <div className="max-w-4xl mx-auto">
          {messages.map((msg, idx) => (
            <ChatMessage key={idx} {...msg} />
          ))}
          
          {isProcessing && assistants.length === 0 && (
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16" />
              <div className="px-6 py-4 rounded-3xl backdrop-blur-xl bg-card/50 border border-card-border">
                <TypingIndicator />
              </div>
            </div>
          )}
          
          <AssistantWorkspace assistants={assistants} isVisible={assistants.length > 0} />
        </div>
      </main>
      
      <ChatInput onSend={handleSend} disabled={isProcessing} />
    </div>
  );
}
