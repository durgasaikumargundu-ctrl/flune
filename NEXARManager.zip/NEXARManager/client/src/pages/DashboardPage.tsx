import { Link } from "wouter";
import ParticleBackground from "@/components/ParticleBackground";
import ProjectDashboard from "@/components/ProjectDashboard";
import ThemeToggle from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { MessageSquare, LogOut } from "lucide-react";

export default function DashboardPage() {
  const managerName = localStorage.getItem("nexar-manager-name") || "Nexar";

  const handleLogout = () => {
    //TODO: remove mock functionality - implement real logout
    localStorage.removeItem("nexar-manager-name");
    window.location.href = "/";
  };

  return (
    <div className="min-h-screen relative">
      <ParticleBackground emotion="calm" />
      
      <header className="fixed top-0 left-0 right-0 z-20 backdrop-blur-xl bg-background/80 border-b border-border">
        <div className="max-w-7xl mx-auto px-8 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold gradient-text">{managerName}</h1>
            <span className="text-xs text-muted-foreground">Your AI Manager</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Link href="/chat">
              <Button variant="ghost" size="sm" data-testid="button-chat">
                <MessageSquare className="w-4 h-4 mr-2" />
                Chat
              </Button>
            </Link>
            <ThemeToggle />
            <Button variant="ghost" size="icon" onClick={handleLogout} data-testid="button-logout">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>
      
      <main className="relative z-10 pt-20">
        <ProjectDashboard />
      </main>
    </div>
  );
}
