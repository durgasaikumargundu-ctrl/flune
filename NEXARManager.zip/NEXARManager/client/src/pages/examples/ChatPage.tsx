import ChatPage from "../ChatPage";

export default function ChatPageExample() {
  localStorage.setItem("nexar-manager-name", "Nexar");
  return <ChatPage />;
}
