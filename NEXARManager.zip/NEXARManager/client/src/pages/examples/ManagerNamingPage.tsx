import ManagerNamingPage from "../ManagerNamingPage";

export default function ManagerNamingPageExample() {
  return <ManagerNamingPage />;
}
