import DashboardPage from "../DashboardPage";

export default function DashboardPageExample() {
  localStorage.setItem("nexar-manager-name", "Nexar");
  return <DashboardPage />;
}
