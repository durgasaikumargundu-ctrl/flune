import { useEffect } from "react";
import { useLocation } from "wouter";
import ParticleBackground from "@/components/ParticleBackground";
import AuthCard from "@/components/AuthCard";
import { signInWithGoogle, signUpWithEmail, signInWithEmail, onAuthChange } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    const unsubscribe = onAuthChange(async (user) => {
      if (user) {
        try {
          const response = await apiRequest("POST", "/api/users", {
            id: user.uid,
            email: user.email,
            displayName: user.displayName || user.email?.split("@")[0],
          });

          const userData = await response.json();
          localStorage.setItem("nexar-user-id", user.uid);
          
          if (userData.managerName) {
            localStorage.setItem("nexar-manager-name", userData.managerName);
            setLocation("/chat");
          } else {
            setLocation("/naming");
          }
        } catch (error: any) {
          console.error("User creation error:", error);
          toast({
            title: "Error",
            description: "Failed to create user account",
            variant: "destructive",
          });
        }
      }
    });

    return () => unsubscribe();
  }, [setLocation, toast]);

  const handleAuth = async (email: string, password: string, isSignup: boolean) => {
    try {
      if (isSignup) {
        await signUpWithEmail(email, password);
      } else {
        await signInWithEmail(email, password);
      }
    } catch (error: any) {
      toast({
        title: "Authentication Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleGoogleAuth = async () => {
    try {
      await signInWithGoogle();
    } catch (error: any) {
      toast({
        title: "Authentication Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      <ParticleBackground emotion="calm" />
      <div className="relative z-10">
        <AuthCard onAuth={handleAuth} onGoogleAuth={handleGoogleAuth} />
      </div>
    </div>
  );
}
