import admin from "firebase-admin";

// Initialize Firebase Admin SDK with application default credentials
// In Replit environment, this will use environment variables for authentication
if (!admin.apps.length) {
  try {
    admin.initializeApp({
      projectId: process.env.VITE_FIREBASE_PROJECT_ID,
    });
  } catch (error) {
    console.error("Failed to initialize Firebase Admin:", error);
  }
}

export const auth = admin.auth();

export async function verifyIdToken(idToken: string): Promise<admin.auth.DecodedIdToken> {
  try {
    const decodedToken = await auth.verifyIdToken(idToken, true);
    return decodedToken;
  } catch (error: any) {
    console.error("Token verification failed:", error.message);
    throw new Error("Invalid authentication token");
  }
}
