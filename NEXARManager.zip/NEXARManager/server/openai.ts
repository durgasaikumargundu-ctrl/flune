// Reference: blueprint:javascript_openai
import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export type EmotionState = "serious" | "excited" | "calm";
export type AssistantType = "Thinker" | "Writer" | "Coder" | "Researcher" | "Designer";

interface AssistantResponse {
  assistant: AssistantType;
  content: string;
}

// Analyze emotion/sentiment of text
export async function analyzeEmotion(text: string): Promise<EmotionState> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "Analyze the emotional tone of the text. Respond with JSON: { 'emotion': 'serious' | 'excited' | 'calm' }. Use 'serious' for professional/work-related, 'excited' for positive/energetic, 'calm' for neutral/waiting states.",
        },
        { role: "user", content: text },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.emotion || "calm";
  } catch (error) {
    console.error("Emotion analysis error:", error);
    return "calm";
  }
}

// Determine which assistants should handle the request
export async function delegateToAssistants(userMessage: string): Promise<AssistantType[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are an AI manager that delegates tasks to specialized assistants:
- Thinker: Analyzes complex questions, plans steps, reasoning, strategy
- Writer: Generates text, articles, reports, documentation, creative content
- Coder: Writes code, debugs, creates technical solutions
- Researcher: Finds facts, summarizes information, gathers data
- Designer: Creative ideas, UI/UX concepts, visual planning

Analyze the user's request and respond with JSON: { "assistants": ["AssistantName1", "AssistantName2"] }
Select 1-3 relevant assistants. Be selective - don't include all assistants unless truly needed.`,
        },
        { role: "user", content: userMessage },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.assistants || ["Thinker"];
  } catch (error) {
    console.error("Delegation error:", error);
    return ["Thinker"];
  }
}

// Get response from a specific assistant
export async function getAssistantResponse(
  assistant: AssistantType,
  userMessage: string,
  conversationContext: string = ""
): Promise<string> {
  const prompts: Record<AssistantType, string> = {
    Thinker: "You are the Thinker assistant. Analyze the request, break it into logical steps, and provide strategic planning. Focus on reasoning and structure.",
    Writer: "You are the Writer assistant. Create well-written, clear, and engaging content. Focus on quality prose and effective communication.",
    Coder: "You are the Coder assistant. Write clean, efficient code with explanations. Provide technical solutions and debugging insights.",
    Researcher: "You are the Researcher assistant. Find relevant information, summarize key facts, and provide data-driven insights.",
    Designer: "You are the Designer assistant. Suggest creative ideas, color schemes, layouts, and visual concepts. Focus on aesthetics and user experience.",
  };

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        { role: "system", content: prompts[assistant] + (conversationContext ? `\n\nContext: ${conversationContext}` : "") },
        { role: "user", content: userMessage },
      ],
      max_completion_tokens: 1024,
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error(`${assistant} error:`, error);
    return `${assistant} is processing your request...`;
  }
}

// Manager combines all assistant responses
export async function managerMergeResponses(
  userMessage: string,
  assistantResponses: AssistantResponse[],
  managerName: string = "Nexar"
): Promise<string> {
  const responseSummary = assistantResponses
    .map((r) => `${r.assistant}: ${r.content}`)
    .join("\n\n");

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are ${managerName}, an AI manager who coordinates a team of specialized assistants. 
Your team has provided their insights below. Your job is to:
1. Synthesize their contributions into a cohesive, helpful response
2. Maintain your personality as a professional AI manager
3. Give credit where appropriate (e.g., "My team analyzed...")
4. Provide a complete, actionable answer to the user

Keep responses concise but comprehensive. Be friendly and professional.`,
        },
        {
          role: "user",
          content: `User asked: "${userMessage}"\n\nTeam responses:\n${responseSummary}\n\nProvide your final synthesized response:`,
        },
      ],
      max_completion_tokens: 2048,
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("Manager merge error:", error);
    return "I've received input from my team and am processing your request. Please try again.";
  }
}

// Extract facts to remember for the user
export async function extractMemoryFacts(userMessage: string, managerResponse: string): Promise<string[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `Extract important facts to remember about the user from this conversation. 
Focus on:
- Personal preferences
- Past requests/projects
- Important details they mentioned
- Goals or interests

Respond with JSON: { "facts": ["fact1", "fact2", ...] }
Return empty array if nothing important to remember.`,
        },
        {
          role: "user",
          content: `User: ${userMessage}\nAssistant: ${managerResponse}`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.facts || [];
  } catch (error) {
    console.error("Memory extraction error:", error);
    return [];
  }
}
