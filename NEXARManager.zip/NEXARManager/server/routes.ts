import type { Express } from "express";
import { createServer, type Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import { storage } from "./storage";
import { authenticateRequest, type AuthRequest } from "./middleware";
import { verifyIdToken } from "./firebase-admin";
import { 
  analyzeEmotion, 
  delegateToAssistants, 
  getAssistantResponse, 
  managerMergeResponses,
  extractMemoryFacts,
  type AssistantType 
} from "./openai";
import { z } from "zod";
import { insertConversationSchema, insertMessageSchema, insertMemorySchema, insertProjectSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
    },
  });

  // User routes
  app.post("/api/users", authenticateRequest, async (req: AuthRequest, res) => {
    try {
      const { displayName } = req.body;
      const uid = req.user!.uid;
      const email = req.user!.email!;
      
      let user = await storage.getUserByEmail(email);
      if (!user) {
        user = await storage.createUser({ id: uid, email, displayName, managerName: null });
      }
      
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/users/:userId", authenticateRequest, async (req: AuthRequest, res) => {
    try {
      const userId = req.user!.uid;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/users/:userId/manager-name", authenticateRequest, async (req: AuthRequest, res) => {
    try {
      const userId = req.user!.uid;
      const { managerName } = req.body;
      await storage.updateUserManagerName(userId, managerName);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Conversation routes
  app.get("/api/conversations/:userId", authenticateRequest, async (req: AuthRequest, res) => {
    try {
      const userId = req.user!.uid;
      const conversations = await storage.getConversationsByUserId(userId);
      res.json(conversations);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/conversations", authenticateRequest, async (req: AuthRequest, res) => {
    try {
      const userId = req.user!.uid;
      const data = insertConversationSchema.parse({ ...req.body, userId });
      const conversation = await storage.createConversation(data);
      res.json(conversation);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/conversations/:conversationId/messages", authenticateRequest, async (req: AuthRequest, res) => {
    try {
      const userId = req.user!.uid;
      const conversationId = req.params.conversationId;
      
      // Verify conversation belongs to user
      const conversation = await storage.getConversation(conversationId);
      if (!conversation || conversation.userId !== userId) {
        return res.status(403).json({ error: "Forbidden: You don't have access to this conversation" });
      }
      
      const messages = await storage.getMessagesByConversationId(conversationId);
      res.json(messages);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Memory routes
  app.get("/api/memories/:userId", authenticateRequest, async (req: AuthRequest, res) => {
    try {
      const userId = req.user!.uid;
      const memories = await storage.getMemoriesByUserId(userId);
      res.json(memories);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Project routes
  app.get("/api/projects/:userId", authenticateRequest, async (req: AuthRequest, res) => {
    try {
      const userId = req.user!.uid;
      const projects = await storage.getProjectsByUserId(userId);
      res.json(projects);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/projects", authenticateRequest, async (req: AuthRequest, res) => {
    try {
      const userId = req.user!.uid;
      const data = insertProjectSchema.parse({ ...req.body, userId });
      const project = await storage.createProject(data);
      res.json(project);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/projects/:projectId", authenticateRequest, async (req: AuthRequest, res) => {
    try {
      const userId = req.user!.uid;
      const projectId = req.params.projectId;
      
      // Verify project belongs to user
      const project = await storage.getProject(projectId);
      if (!project || project.userId !== userId) {
        return res.status(403).json({ error: "Forbidden: You don't have access to this project" });
      }
      
      await storage.updateProject(projectId, req.body);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Socket.io for real-time AI chat with authentication
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token;
      if (!token) {
        return next(new Error("Authentication required"));
      }

      const decodedToken = await verifyIdToken(token);
      socket.data.userId = decodedToken.uid;
      socket.data.email = decodedToken.email;
      next();
    } catch (error) {
      next(new Error("Invalid authentication token"));
    }
  });

  io.on("connection", (socket) => {
    const userId = socket.data.userId;
    console.log("Client connected:", socket.id, "User:", userId);

    socket.on("chat-message", async (data) => {
      const { conversationId, userMessage, managerName } = data;

      try {
        // Verify conversation belongs to authenticated user
        const conversation = await storage.getConversation(conversationId);
        if (!conversation || conversation.userId !== userId) {
          socket.emit("error", { message: "Unauthorized access to conversation" });
          return;
        }

        // Get user memories for context
        const memories = await storage.getMemoriesByUserId(userId);
        const memoryContext = memories.map(m => m.fact).join(". ");

        // Step 1: Analyze emotion
        const emotion = await analyzeEmotion(userMessage);
        socket.emit("emotion-detected", { emotion });

        // Step 2: Determine which assistants to use
        const assistantTypes = await delegateToAssistants(userMessage);
        socket.emit("assistants-activated", { assistants: assistantTypes });

        // Step 3: Get responses from each assistant with progress updates
        const assistantResponses = [];
        for (let i = 0; i < assistantTypes.length; i++) {
          const assistant = assistantTypes[i];
          socket.emit("assistant-progress", {
            assistant,
            status: "working",
            progress: 0,
          });

          const response = await getAssistantResponse(assistant, userMessage, memoryContext);
          assistantResponses.push({ assistant, content: response });

          socket.emit("assistant-progress", {
            assistant,
            status: "done",
            progress: 100,
          });
        }

        // Step 4: Manager merges responses
        const finalResponse = await managerMergeResponses(
          userMessage,
          assistantResponses,
          managerName || "Nexar"
        );

        // Save user message
        await storage.createMessage({
          conversationId,
          role: "user",
          content: userMessage,
          emotion: null,
          assistants: null,
        });

        // Save manager response
        await storage.createMessage({
          conversationId,
          role: "manager",
          content: finalResponse,
          emotion,
          assistants: assistantTypes,
        });

        // Extract and save memory facts
        const facts = await extractMemoryFacts(userMessage, finalResponse);
        for (const fact of facts) {
          await storage.createMemory({
            userId,
            fact,
          });
        }

        socket.emit("manager-response", {
          content: finalResponse,
          emotion,
          assistants: assistantTypes,
        });
      } catch (error: any) {
        console.error("Chat error:", error);
        socket.emit("error", { message: error.message });
      }
    });

    socket.on("disconnect", () => {
      console.log("Client disconnected:", socket.id);
    });
  });

  return httpServer;
}
